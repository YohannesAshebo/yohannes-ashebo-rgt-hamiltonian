"""Pressure gradients and exact stream forcing in the existing Hamiltonian."""
import json
from pathlib import Path

import numpy as np

from common import LD, ROOT
from model import build

OUT = Path(__file__).resolve().parent
HALF_BAND = .10


def scalar(x):
    return float(x)


def as_list(a):
    return np.asarray(a, dtype=float).tolist()


def collect(n, g, time):
    m, _, _ = build(n, g)
    stem = f'g_{g:.2f}_N{n}'
    path = (OUT / f'{stem}_s5.npz' if time == 5
            else ROOT / 'exchange_volume' / f'{stem}_restart.npz')
    y = np.load(path)['state']
    d = m.evaluate(y)
    core = m.core(y, d)
    q, grad, rhs = (m.unpack(x) for x in (y, d['gradient'], d['rhs']))
    alpha, beta = q[4:6]
    r = m.r
    faces = m.faces[1:-1]
    base = m.base.terms_and_gradient(m.to_original(y))
    volume = d['V']
    pressure = base['pressure_local']
    radial_stress = -grad[4] / volume
    mean_stress = -(grad[4] + grad[5]) / (3 * volume)
    eps = LD('1e-7')
    idx = int(np.argmin(abs(r - core['coordinate_radius'])))
    a = q.copy()
    b = q.copy()
    a[4:6, idx] += eps / 3
    b[4:6, idx] -= eps / 3
    fd = -(m.hamiltonian(a.ravel()) - m.hamiltonian(b.ravel())) / (2 * eps * volume[idx])
    assert abs(fd - mean_stress[idx]) < 1e-7

    mu = grad[:2] / d['N']
    signed_momentum = m.p.eta * np.diff(q[2:4], axis=1) / d['L']
    strain_rate = (rhs[4, :-1] + rhs[4, 1:]) / 2
    chemical_force = -np.diff(mu, axis=1) / d['L']
    total_momentum_rate = chemical_force - signed_momentum * strain_rate
    pressure_fields = {'local_pressure': pressure, 'radial_stress': radial_stress,
                       'mean_stress': mean_stress}
    fields = {**pressure_fields, 'alpha': alpha, 'beta': beta,
              'total_density': d['density'].sum(axis=0)}
    face_fields = {k + '_gradient': np.diff(p) / d['L'] for k, p in pressure_fields.items()}
    face_fields.update(dict(convergence_force=chemical_force[0], divergence_force=chemical_force[1],
                            convergence_momentum_rate=total_momentum_rate[0],
                            divergence_momentum_rate=total_momentum_rate[1]))
    return dict(core=core, centers=r, faces=faces, fields=fields, face_fields=face_fields,
                fd_stress_error=scalar(abs(fd - mean_stress[idx])))


def point(data, radius):
    def interp(grid, vals, x):
        return np.interp(x, grid.astype(float), vals.astype(float))

    result = {'coordinate': radius}
    result.update({k: scalar(interp(data['centers'], v, radius))
                   for k, v in data['fields'].items()})
    left, right = radius - HALF_BAND, radius + HALF_BAND
    x = data['faces']
    interior = x[(x > left) & (x < right)]
    points = np.r_[left, interior, right]
    for k, v in data['face_fields'].items():
        result[k] = scalar(interp(x, v, radius))
        result[k + '_band_mean'] = scalar(np.trapezoid(interp(x, v, points), points) / (2 * HALF_BAND))
    return result


def run():
    summary = {}
    for n in (256, 512):
        for time in (5, 6):
            c, g = [collect(n, coupling, time) for coupling in (0., 1.)]
            control_r = c['core']['coordinate_radius']
            profiles = {}
            for key, d in [('control', c), ('coupled', g)]:
                profiles[key] = dict(own_boundary=point(d, d['core']['coordinate_radius']),
                                     control_boundary=point(d, control_r),
                                     central_strains={k: scalar(d['fields'][k][0]) for k in ('alpha', 'beta')},
                                     areal_radius=d['core']['areal_radius'],
                                     stress_finite_difference_error=d['fd_stress_error'])
                result = {k: as_list(d[k]) for k in ('centers', 'faces')}
                result.update({k: as_list(v) for group in ('fields', 'face_fields') for k, v in d[group].items()})
                (OUT / f'{key}_N{n}_s{time}_profile.json').write_text(json.dumps(result, allow_nan=False) + '\n')
            summary[f'N{n}_s{time}'] = profiles
    (OUT / 'SUMMARY.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    run()
