# RGT pressure diagnostic for direct exchange–volume feedback

Compare g_space=0 and 1 on the original 256 and 512 radial cells at
s=5 and s=6. The s=6 states come from the saved trajectories. Replay
the same integrator to s=5 because the previous archive kept scalar
readouts there and saved the full state only at s=6. Check the replay
against the saved areal radius and signed retention.

The profiles distinguish three quantities.

- Local pressure is the existing p_U = n U_n + chi U_chi - U.
- Compressive radial stress is -(dH/dalpha)/V, holding other canonical
  variables fixed. It contains the geometry and nonlocal contributions.
- Mean compressive stress is -(dH/dalpha+dH/dbeta)/(3V), the virtual
  response to isotropic log-volume strain at fixed canonical contents,
  phases and momenta. A centered energy finite difference verifies it.

Pressure and stress gradients use proper radial face distance.
Compare at each moving equality boundary and at a matched coordinate
(the control boundary at that time and resolution). Save point values
and coordinate-band means over +/-0.10 model radius around each probe.
The band averages reduce sensitivity to selecting one face. Positive
force is outward. The canonical stream force is -Delta(mu)/L where
mu is the full Hamiltonian derivative with respect to stream content.
The momentum rate also includes the radial metric strain-rate term.
This is an observational comparison between evolved states. It does
not isolate a causal pressure-only intervention or add a Hamiltonian term.

Extract the pressure supplement and all inputs of the exchange-volume
supplement into the force-balance archive root. From there:

    export PYTHONPATH=.:study:speed_order:speed_sweep:exchange_volume
    python pressure_diagnostic/replay.py CELLS COUPLING
    python -m pressure_diagnostic.pressure_profiles

Run the replays for 256 and 512 cells and couplings 0 and 1.

At the matched coordinate, local pressure-gradient changes agree in
sign at s=5 but disagree at s=6 across resolutions. Radial-stress
gradient changes at s=6 also disagree in sign. The band-average
convergence momentum rate is outward at all four comparisons, at
either run's boundary or the matched coordinate. The coupling weakens
the outward band-average at the matched coordinate in all four
comparisons, but does not produce inward acceleration there. At
the innermost sampled cell, radial and tangential log strains are
nearly equal, so the center is locally close to isotropic. The
shrinking equality radius describes a distinct outer boundary.
