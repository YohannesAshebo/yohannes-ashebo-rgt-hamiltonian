"""Recover the s=5 state using the original trajectory cadence and integrator."""
import argparse
import json
from pathlib import Path

import numpy as np

from common import ExtendedDOP853, ROOT
from model import build

OUT = Path(__file__).resolve().parent


def replay(cells, coupling):
    model, initial, _ = build(cells, coupling)
    stem = f'g_{coupling:.2f}_N{cells}'
    reference = json.loads((ROOT / 'exchange_volume' / f'{stem}.json').read_text())['rows']
    solver = ExtendedDOP853(model.rhs, 0., initial, 5., rtol=2.5e-12, atol=2e-14, max_step=.005)
    for time in np.arange(1, 101) / 20:
        solver.t_bound = float(time)
        solver.status = 'running'
        while solver.status == 'running':
            message = solver.step()
            if solver.status == 'failed':
                raise RuntimeError(message)
    y = solver.y
    core = model.core(y)
    assert abs(core['areal_radius'] - reference[100]['areal_radius']) < 1e-12
    assert abs(core['signed_content'] - reference[100]['signed_content']) < 1e-12
    np.savez_compressed(OUT / f'{stem}_s5.npz', state=y)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('cells', type=int)
    parser.add_argument('coupling', type=float)
    args = parser.parse_args()
    replay(args.cells, args.coupling)
